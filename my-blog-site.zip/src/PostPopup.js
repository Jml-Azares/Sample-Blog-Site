// import React from "react";

// function PostPopup({ post, onClose }) {
//   return (
//     <div className="post-popup-overlay" onClick={onClose}>
//       <div className="post-popup-content">
//         <h2>{post.title}</h2>
//         <p>
//           By {post.author} on {post.date}
//         </p>
//         <p>{post.content}</p>
//         <button className="btn btn-dark" onClick={onClose}>
//           Close
//         </button>
//       </div>
//     </div>
//   );
// }

// export default PostPopup;
